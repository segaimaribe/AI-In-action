# i & ii. Load the Dataset and Use pandas to read the CSV file
import pandas as pd
import matplotlib.pyplot as plt
from fpdf import FPDF

# --- Create the dataset ---
data = {
    "StudentID": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
                  11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
                  21, 22, 23, 24, 25, 26, 27, 28, 29, 30],
    "Hours_Studied": [7, 7, 5, 7, 8, 4, 1, 3, 4, 1,
                      4, 1, 5, 7, 3, 1, 10, 6, 10, 3,
                      4, 8, 2, 7, 7, 2, 8, 2, 4, 7],
    "Attendance_Percent": [61, 83, 82, 54, 96, 76, 97, 60, 78, 96,
                           51, 60, 64, 80, 85, 52, 76, 87, 53, 76,
                           67, 75, 54, 53, 78, 93, 85, 70, 61, 88],
    "Passed": ['Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'Yes', 'No', 'Yes',
               'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'Yes', 'No', 'Yes', 'Yes',
               'No', 'Yes', 'Yes', 'Yes', 'No', 'Yes', 'No', 'No', 'Yes', 'No']
}

# Convert to DataFrame
df = pd.DataFrame(data)

# iii. Display the Data
print("Full Dataset:\n", df)

# iv. Print the first 5 rows
print("\nFirst 5 rows:\n", df.head())

# v. Check how many students passed vs failed
pass_fail_counts = df['Passed'].value_counts()
print("\nNumber of students who passed vs failed:\n", pass_fail_counts)

# vi. Calculate the average hours studied
average_hours = df['Hours_Studied'].mean()
print("\nAverage hours studied:", round(average_hours, 2))

# vii. Find the average attendance of students who passed
passed_students = df[df['Passed'] == 'Yes']
average_attendance_passed = passed_students['Attendance_Percent'].mean()
print("\nAverage attendance of students who passed:", round(average_attendance_passed, 2))


# --- 📊 Plot: Passed vs Failed ---
pass_fail_counts.plot(kind='bar', color=['green', 'red'])
plt.title('Students: Passed vs Failed')
plt.xlabel('Result')
plt.ylabel('Number of Students')
plt.tight_layout()
plt.savefig('pass_fail_bar_chart.png')
plt.close()

# --- 📊 Plot: Histogram of Hours Studied ---
plt.hist(df['Hours_Studied'], bins=7, color='skyblue', edgecolor='black')
plt.title('Distribution of Hours Studied')
plt.xlabel('Hours Studied')
plt.ylabel('Number of Students')
plt.tight_layout()
plt.savefig('hours_studied_histogram.png')
plt.close()

# --- 📊 Plot: Scatter Plot of Attendance vs Hours (colored by Passed/Failed) ---
colors = df['Passed'].map({'Yes': 'green', 'No': 'red'})
plt.scatter(df['Hours_Studied'], df['Attendance_Percent'], c=colors)
plt.title('Hours Studied vs Attendance')
plt.xlabel('Hours Studied')
plt.ylabel('Attendance (%)')
plt.tight_layout()
plt.savefig('scatter_hours_vs_attendance.png')
plt.close()


# --- Export Results to PDF ---
pdf = FPDF()
pdf.add_page()
pdf.set_font("Arial", size=12)

# Title
pdf.cell(200, 10, txt="Student Performance Report", ln=True, align='C')
pdf.ln(10)

# Summary Section
pdf.cell(200, 10, txt="Summary Statistics", ln=True, align='L')
pdf.ln(5)
pdf.cell(200, 10, txt=f"Total Students: {len(df)}", ln=True)
pdf.cell(200, 10, txt=f"Passed: {pass_fail_counts.get('Yes', 0)}", ln=True)
pdf.cell(200, 10, txt=f"Failed: {pass_fail_counts.get('No', 0)}", ln=True)
pdf.cell(200, 10, txt=f"Average Hours Studied: {round(average_hours, 2)}", ln=True)
pdf.cell(200, 10, txt=f"Average Attendance of Students Who Passed: {round(average_attendance_passed, 2)}%", ln=True)

pdf.ln(10)

# Data Table Header
pdf.set_font("Arial", "B", size=10)
page_width = pdf.w - 2 * pdf.l_margin
col_width = page_width / 4

pdf.cell(col_width, 10, "StudentID", 1)
pdf.cell(col_width, 10, "Hours_Studied", 1)
pdf.cell(col_width, 10, "Attendance", 1)
pdf.cell(col_width, 10, "Passed", 1)
pdf.ln()

# Data Table Rows
pdf.set_font("Arial", size=10)
for i in range(len(df)):
    pdf.cell(col_width, 10, str(df.iloc[i]['StudentID']), 1)
    pdf.cell(col_width, 10, str(df.iloc[i]['Hours_Studied']), 1)
    pdf.cell(col_width, 10, str(df.iloc[i]['Attendance_Percent']), 1)
    pdf.cell(col_width, 10, str(df.iloc[i]['Passed']), 1)
    pdf.ln()

# --- Insert Graph Images ---
pdf.add_page()
pdf.set_font("Arial", "B", 12)
pdf.cell(200, 10, txt="Graphs & Visualizations", ln=True, align='C')
pdf.ln(5)

# Insert bar chart
pdf.image("pass_fail_bar_chart.png", x=10, y=None, w=pdf.w - 20)
pdf.ln(5)

# Insert histogram
pdf.image("hours_studied_histogram.png", x=10, y=None, w=pdf.w - 20)
pdf.ln(5)

# Insert scatter plot
pdf.image("scatter_hours_vs_attendance.png", x=10, y=None, w=pdf.w - 20)

# Save the PDF
pdf.output("student_report.pdf")
print("\n✅ PDF saved as 'student_report.pdf'")
